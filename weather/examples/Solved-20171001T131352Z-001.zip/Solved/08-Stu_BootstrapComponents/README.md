# Bootstrap Components

* In this activity we will research and utilize Bootstrap components inside of an HTML document.

## Instructions

* With a partner, navigate to <http://getbootstrap.com/components/>

* Create a new HTML file, try to include at least 10 different Bootstrap components in this file, and be ready to discuss after the activity.

* You can add a Bootstrap component inside of your document by copying and pasting any of the examples on the Bootstrap Components page.
