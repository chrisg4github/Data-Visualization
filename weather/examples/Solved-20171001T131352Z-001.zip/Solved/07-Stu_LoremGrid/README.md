# Lorem Grid

* In this activity we will attempt to recreate a layout using the Bootstrap grid.

## Instructions

* Open the [Unsolved Folder](Unsolved) and open the `04-Lorem-Grid.png` file inside.

* Take a moment to study the image, and create this layout using the Bootstrap grid.

* You can use [lorem ipsum](http://www.lipsum.com/) for the text.

* You can read about the grid system here: <http://getbootstrap.com/css/#grid>

## Hints

* Container > Row > Column
